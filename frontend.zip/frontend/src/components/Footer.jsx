import React from 'react'

const Footer = () => {
  return (
    <div className='text-center mb-10 mt-10'>
      <h1>© 2024 Revanth Shiva. All rights reserved.</h1>
    </div>
  )
}

export default Footer